sDot=ExFUN2(15,125)

SInit=0;
tSpan=[0 20];

[T Y]=ode45(@ExFUN2,tSpan,SInit);

S=AbsolutelyFunFunction(15)

S_a=AbsolutelyFunFunction(T);

subplot(2,1,1), plot(T,Y,'b',T,S_a,'r')
title('Solution Plots')
xlabel('Time (t)')
ylabel('S(t)')
legend('ODE45 Solution','Analytical Solution','Location','best')
subplot(2,1,2), plot(T,abs((S_a-Y)))
title('Residual Plot,Max Error Occurs at Discontinuity')
xlabel('Time (t)')
ylabel('Error')

type ExFUN2

type AbsolutelyFunFunction