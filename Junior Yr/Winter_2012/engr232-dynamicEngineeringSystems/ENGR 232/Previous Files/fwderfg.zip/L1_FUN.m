function y= L1_FUN (t)
nT=numel(t);
y=zeros(1,nT);

for k=1:nT
    if (t(k)>=pi) & (t(k)<= (2*pi))
        y(k) = 0
    else
        y(k) = sin(t(k))
    end
end 

