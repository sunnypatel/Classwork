function Q12dot = Qdot(t,Q12) 

Q1=Q12(1,1); 
Q2=Q12(2,1); 
  
Q1dot = -0.1*Q1+0.0075*Q2+1.5; 
Q2dot = 0.1*Q1 -0.2*Q2 + 3; 
  
Q12dot(1,1) = Q1dot; 
Q12dot(2,1) = Q2dot;