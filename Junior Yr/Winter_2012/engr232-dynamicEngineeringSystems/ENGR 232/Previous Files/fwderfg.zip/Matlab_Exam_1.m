XYDot=ExFun1(1,[1;0])

XYInit=[0;7];
tSpan=[0 10];
A=[-3 2; -2 -3];
b=[0;0];
eqPt=A^-1*b;

[t XY]=ode45(@ExFUN1,tSpan,XYInit);

subplot(2,2,[1 2]), plot(XY(:,1),XY(:,2),'b')
hold on
plot(XYInit(1),XYInit(2),'c*',eqPt(1),eqPt(2),'r*')
title('Phase Portrait, Version C')
xlabel('X Position')
ylabel('Y Position')
legend('Trajectory',['Initial Condition= (' num2str(XYInit(1)) ',' num2str(XYInit(2)) ')'],['Equilibrium Point (' num2str(eqPt(1)) ',' num2str(eqPt(2)) ')'])
axis ([-7 10 -1 XYInit(2)])
grid on

subplot(2,2,3), plot(t,XY(:,1))
xlabel('Time (t)')
ylabel('x(t)')
axis([0 3 -1 2])
grid on

subplot(2,2,4), plot(t,XY(:,2))
xlabel('Time (t)')
ylabel('y(t)')
axis([0 3 -5 10])
grid on

type ExFUN1