function sDot=ExFUN2(t,S)
    if t<=10
        sDot=8-(S/125);
    else
        sDot=-(S/125);
    end
end