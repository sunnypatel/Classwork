%% Intialize
clear,clc

tSPAN=[0 30];
qINT = [0 20 50];
color = ['b' 'g' 'r'];

%% Solutions
for i=1:numel(qINT)
    [t q]=ode45(@diffeq,tSPAN,qINT(i));
    
    plot(t,q,color(i))
    grid on
    
    xlabel('Time (seconds)')
    ylabel('Magnitude')
    title('Lab 3, In Class Solution')
    legend('q(0)=0','q(0)=20','q(0)=50')
    hold on
end

