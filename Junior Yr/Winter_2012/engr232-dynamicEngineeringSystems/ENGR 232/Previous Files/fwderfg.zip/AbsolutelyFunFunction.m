function s=AbsolutelyFunFunction(t)
[rows_t, cols_t]=size(t);
s=zeros(rows_t, cols_t);

for i=1:numel(t)
    if t(i)<=10
        s(i)=1000*(1-exp(-t(i)/125));
    else
        s(i)=76.88*exp(-(t(i)-10)/125);
    end
end