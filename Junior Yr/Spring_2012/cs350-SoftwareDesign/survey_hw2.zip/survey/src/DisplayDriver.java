
public abstract class DisplayDriver {

	public DisplayDriver(){
		
	}
	
	public abstract void draw();
	
	public abstract void draw(Object x);
}
