Please put all game boards in the folder "GameBoards" for testing, that's where src code is looking for them.
