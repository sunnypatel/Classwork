package drugiee;

public class Patient {
	public String first_name;
	public String middle_name;
	public String last_name;
	public String dob;
	
	public Patient(){
		
	}
}
